
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","lkdev\\myGateway\\myGatewayClient"],["c","lkdev\\myGateway\\myGatewayClientException"]];
